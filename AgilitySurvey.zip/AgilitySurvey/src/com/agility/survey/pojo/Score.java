package com.agility.survey.pojo;

public enum Score {
	LOW, MEDIUM, HIGH
}
